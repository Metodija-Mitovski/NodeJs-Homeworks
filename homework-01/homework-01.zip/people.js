module.exports = [
  { name: "Brad", lastName: "Gibson", age: 18 },
  { name: "Lilian", lastName: "Rebecka", age: 24 },
  { name: "Bonnie", lastName: "Franklin", age: 16 },
  { name: "Logan", lastName: "Walker", age: 37 },
  { name: "Richard", lastName: "Ward", age: 14 },
  { name: "Fernando", lastName: "Berry", age: 16 },
  { name: "Wilma", lastName: "Arnes", age: 28 },
  { name: "Isabella", lastName: "Clarke", age: 46 },
  { name: "Elliot", lastName: "Li", age: 25 },
  { name: "Kathy", lastName: "Romero", age: 17 },
  { name: "Cathy ", lastName: "Meyer", age: 15 },
  { name: "Violet", lastName: "Thomsen", age: 22 },
];

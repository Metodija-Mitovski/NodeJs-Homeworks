module.exports = {
  macedonia: 18,
  serbia: 18,
  slovenia: 18,
  usa: 21,
  netherlands: 18,
  russia: 18,
  japan: 20,
  cyprus: 17,
  cuba: 18,
  indonesia: 21,
};
